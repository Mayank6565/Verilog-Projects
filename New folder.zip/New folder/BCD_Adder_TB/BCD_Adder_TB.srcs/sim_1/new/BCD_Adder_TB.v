
module BCD_Adder_TB(

    );
    reg [3:0]a,b;
    reg c_in;
    wire [3:0]sum;
    wire carry;
    BCD_Adder dut(a,b,c_in,sum,carry);
    initial 
    begin
    $monitor("a=%b,b=%b,c_in=%b,sum=%b,carry=%b",a,b,c_in,sum,carry);
    a=4'b0011;
    b=4'b0100;
    c_in=1'b0;
    #1;
    
     a=4'b0101;
    b=4'b0011;
    c_in=1'b0;
    #1;
    
     a=4'b0101;
    b=4'b0101;
    c_in=1'b0;
    #1;
    
     a=4'b0111;
    b=4'b0101;
    c_in=1'b0;
    #1;
    $finish;
    end
    
endmodule
