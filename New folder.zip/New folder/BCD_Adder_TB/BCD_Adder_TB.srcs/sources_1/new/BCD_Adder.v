

module BCD_Adder(
input [3:0]a,b,input c,output [3:0]sum,output carry
    );
    reg [4:0]temp;
    always@(*)
    begin
    temp= a + b;
    if(temp>'d9)
    temp = temp + 4'b0110;
    else
    
    temp = temp;
    
    end
    assign sum = temp[3:0];
    assign carry = temp[4];

endmodule
