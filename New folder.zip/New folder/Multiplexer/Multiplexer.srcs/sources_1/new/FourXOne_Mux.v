

module FourXOne_Mux(input [3:0]I,input [1:0]S, output Y);
wire w1,w2,w3,w4,w5,w6;
not n1(w1,S[1]);
not n2(w2,S[0]);
and a1(w3,I[0],w2,w1);
and a2(w4,I[1],w1,S[0]);
and a3(w5,I[2],S[1],w2);
and a4(w6,I[3],S[1],S[0]);
or o1(Y,w3,w4,w5,w6);
endmodule
