

module Top_using_4x1_mux(input w,x,y,z, output F);
wire P,Q;
FourXOne_Mux M1(
.I(4'b0110),
.S({w,x}),
.Y(P)
);
FourXOne_Mux M2(
.I(4'b1010),
.S({w,x}),
.Y(Q)
);
FourXOne_Mux M3(
.I({1'b1,Q,1'b0,P}),
.S({y,z}),
.Y(F)
);

endmodule