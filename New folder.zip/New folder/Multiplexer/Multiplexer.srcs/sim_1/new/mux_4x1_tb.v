
module mux_4x1_tb;

  reg [1:0] s;
  reg [3:0] i;
  wire y;
  integer m;

  mux_4x1_case dut (s, i, y);

  initial
    begin
      $monitor("Value of s = %b, i = %b, y = %b", s, i, y);
      for (m = 0; m < 64; m = m + 1)
        begin
          {i, s} = m;
          #1;
        end
      $finish;
    end
endmodule