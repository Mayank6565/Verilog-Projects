
module ALU_TB(

    );
    reg rst;
    reg [2:0] op;
    reg [7:0]A,B;
    wire zero,carry,overflow,negative;
    wire [7:0]result;
    integer i;
    
    ALU_Project dut(rst,op,A,B,result,carry,overflow,zero,negative);
     
     task reset;
     begin
     rst=1;
     #10;
     rst=0;
     op=3'd0;
     #10;
     end
     endtask
     
     initial
     begin
     $monitor("time=%0t,rst=%b,op=%b,carry=%b,overflow=%b,zero=%b,negative=%b,A=%b,B=%b,result=%b",$time,rst,op,carry,overflow,zero,negative,A,B,result);
     A=8'b11010011;
     B=8'b01101110;
     
     reset();
     //Functional Cases
     for(i=0;i<8;i=i+1)
     begin
     op=i;
     #10;
     end
     
     //Corner Cases
     
     //Overflow
     A=8'd127;
     B=8'd1;
     op=3'b000;
     #10;
     
     //Carry
     A=8'd255;
     B=8'd1;
     op=3'b000;
     #10;
     
     //Negative Overflow
      A=8'd100;
     B= -8'd50;
     op=3'b001;
     #10;
     
     //Zero
      A=8'd5;
     B= 8'd5;
     op=3'b001;
     #10;
     
     //Negative
      A=8'd5;
     B= 8'd10;
     op=3'b001;
     #10;
     
     //Left Shift Carry
     A=8'b10010011;
     op=3'b110;
     #10;
     
     //Right Shift  Carry
     A=8'b10010011;
     op=3'b111;
     #10;
     
     reset();
     $finish;
     end
endmodule
