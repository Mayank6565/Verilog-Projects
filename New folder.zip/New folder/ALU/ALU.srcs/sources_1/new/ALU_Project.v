

module ALU_Project(
input rst,input [2:0]op,input [7:0]A,B,output reg[7:0] result,
output reg carry,
output reg overflow,
output reg zero,
output reg negative
    );
    
    always@(*)
    begin
    carry=0;
    overflow=0;
    if(rst)
        result=8'd0;
    else
    begin
    case (op)
    3'b000:  begin
            {carry,result}= A+B;
            if((!A[7]&&!B[7]&&result[7]) | (A[7]&&B[7]&&!result[7])) 
            overflow=1;
            end
    3'b001:  begin
            {carry,result}= A-B;
            if((!A[7]&&B[7]&&result[7]) | (A[7]&&!B[7]&&!result[7])) 
            overflow=1;
            end
    3'b010:  result= A&B;
    3'b011:  result= A|B;
    3'b100:  result= A^B;
    3'b101:  result= ~A;
    3'b110:  begin
             carry= A[7];
            result= A<<1;
            end
            
    3'b111:  begin
             carry= A[0];
            result= A>>1;
            end
            
    default: result=8'd0; 
    endcase
    end
  zero = (result==0);
  negative =result[7];
  end
endmodule
