
module Seq_1011001_non_over_moore_TB(

    );
    reg clk,rst,x;
    wire z;
    Seq_1011001_non_over_moore dut(rst,clk,x,z);
    
    
    task reset_dut;
    begin
    rst=1;
    x=0;
    @(posedge clk);
    #1;
    rst=0;
    #1;
    end
    endtask
    
    
    task send_bit;
    input b;
    begin
    x=b;
    @(posedge clk);
    #1;
    end
    endtask
    
    
     initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t x=%b state=%b z=%b next_state=%b",
         $time,x,dut.state,z,dut.next_state);
    
    reset_dut();
    //One match
    send_bit(1);
    send_bit(0);
    send_bit(1);
    send_bit(1);
    send_bit(0);
    send_bit(0);
    send_bit(1);
    @(posedge clk);

#1;//To effectively observe the waveform in Specially Moore Machine
    
    
    reset_dut();
    //2 matches
    send_bit(1);
    send_bit(0);
    send_bit(1);
    send_bit(1);
    send_bit(0);
    send_bit(0);
    send_bit(1);
    send_bit(1);
    send_bit(0);
    send_bit(1);
    send_bit(1);
    send_bit(0);
    send_bit(0);
    send_bit(1);
    @(posedge clk);

#1;
    
    
    reset_dut();
    //All 1's checking
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    @(posedge clk);

#1;
    
    reset_dut();
    //Random Pattern
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(0);
    send_bit(1);
    send_bit(0);
    send_bit(1);
    send_bit(1);
    send_bit(1);
    send_bit(0);
    @(posedge clk);

#1;
    
    @(posedge clk);
    #1;
    $finish;
    end
endmodule
