

module Sequence_1101_TB(

    );
    reg clk,rst,x;
    wire z;
    Sequence_1101 dut(clk,rst,x,z);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t x=%b state=%b z=%b next_state=%b",
         $time,x,dut.state,z,dut.next_state);
    rst=1;
    x=0;
    @(posedge clk);
    #1;
    rst=0;
    #1;
    //Single detection
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    #1;
    
    //No detection
    rst=1;
@(posedge clk);
#1;
rst=0;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    #1;
    
    
    //Two detection
    rst=1;
@(posedge clk);
#1;
rst=0;
     @(posedge clk);
    x=1;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    #1;
    
    //All Ones-No Detection
    rst=1;
@(posedge clk);
#1;
rst=0;
    repeat(6)
begin
    @(posedge clk);
    x = 1;
end
    #1;
    
    //Random Checking
    rst=1;
@(posedge clk);
#1;
rst=0;
     @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=1;
    @(posedge clk);
    x=0;
    
    @(posedge clk);
    #1;
    $finish;
    end
endmodule
