
module Seq_1011001_non_over_moore(
input rst,clk,x,output z
    );
    parameter S0= 3'd0;
    parameter S1= 3'd1;
    parameter S2= 3'd2;
    parameter S3= 3'd3;
    parameter S4= 3'd4;
    parameter S5= 3'd5;
    parameter S6= 3'd6;
    parameter S7= 3'd7;
    reg [2:0] state,next_state;
    always@(posedge clk)
    begin
    if(rst)
        state<= S0;
     else 
        state<=next_state;   
    end
    
    always@(*)
    begin
    case(state)
    S0: begin
        if(x)
            next_state=S1;
         else   
            next_state=S0;
         end   
    S1: begin
        if(x)
            next_state=S1;
         else   
            next_state=S2;
         end 
    S2: begin
        if(x)
            next_state=S3;
         else   
           next_state=S0;
         end 
         
    S3: begin
        if(x)
            next_state=S4;
         else   
            next_state=S2;
         end 
         
    S4: begin
        if(x)
            next_state=S1;
         else   
            next_state=S5;
         end 
         
     S5: begin
        if(x)
            next_state=S3;
         else   
            next_state=S6;
         end 
         
     S6: begin
        if(x)
            next_state=S7;
         else   
            next_state=S0;
         end 
         
     S7: next_state=S0;
   
     default: next_state<= S0;
                                          
    endcase
    end
    
    assign z=(state==S7);
    
    
    
    
endmodule
