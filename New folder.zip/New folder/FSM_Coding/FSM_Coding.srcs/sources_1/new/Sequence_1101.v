

module Sequence_1101(
input clk,rst,x,output reg z
    );
    parameter S0=2'b00;
    parameter S1=2'b01;
    parameter S2=2'b10;
    parameter S3=2'b11;
    reg [1:0] state,next_state;
    
    
    always@(posedge clk)
    begin
    if(rst)
        state<=S0;
     else 
        state<=next_state;    
    end
    
    always@(*)
    begin
    case(state)
    S0: begin
        if(x)
            next_state = S1;
         else 
            next_state = S0;
         end
         
    S1:      begin
        if(x)
            next_state = S2;
         else 
            next_state = S0;
         end
    S2:  begin
        if(x)
            next_state = S2;
         else 
            next_state = S3;
         end      
         
    S3:   begin
        if(x)
            next_state = S1;
         else 
            next_state = S0;
         end   
         
    default: next_state =S0;              
    endcase
    
    end
    
    always@(*)
    begin
    z=1'b0;
    case(state)
    S3: begin
        if(x)
            z=1'b1;
        end
    default: z=1'b0;        
    endcase
    
    end
    
    
endmodule
