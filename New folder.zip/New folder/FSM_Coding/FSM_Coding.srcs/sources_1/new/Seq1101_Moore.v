
module Seq1101_Moore(
input rst,clk,x,output z
    );
     parameter S0=3'd0;
    parameter S1=3'd1;
    parameter S2=3'd2;
    parameter S3=3'd3;
    parameter S4=3'd4;
    
    reg [2:0] state,next_state;
    
    
     always@(posedge clk)
    begin
    if(rst)
        state<=S0;
     else 
        state<=next_state;    
    end
    
    always@(*)
    begin
    case(state)
    S0: begin
        if(x)
            next_state = S1;
         else 
            next_state = S0;
         end
         
    S1:      begin
        if(x)
            next_state = S2;
         else 
            next_state = S0;
         end
    S2:  begin
        if(x)
            next_state = S2;
         else 
            next_state = S3;
         end      
         
    S3:   begin
        if(x)
            next_state = S4;
         else 
            next_state = S0;
         end   
         
     S4:   begin
        if(x)
            next_state = S2;
         else 
            next_state = S0;
         end     
         
    default: next_state =S0;              
    endcase
    
    end
    
    assign z=(state==S4);
    
  
    
endmodule
