
module Sequence_1010_With_Non_Overlapping(
input rst,clk,x,output z
    );
    parameter S0=2'b00;
    parameter S1=2'b01;
    parameter S2=2'b10;
    parameter S3=2'b11;
    reg [1:0] state,next_state;
    
    always@(posedge clk)
    begin
    if(rst)
        state<=S0;
     else 
          state<=next_state;
     end
     
     always@(*)
     begin
     case(state)
    S0: begin
        if(x)
            next_state = S1;
         else 
            next_state = S0;
         end
         
    S1:      begin
        if(x)
            next_state = S1;
         else 
            next_state = S2;
         end
    S2:  begin
        if(x)
            next_state = S3;
         else 
            next_state = S0;
         end      
         
    S3:   begin
        if(x)
            next_state = S1;
         else 
            next_state = S0;
         end   
         
    default: next_state =S0;              
    endcase
    
     end
          
   assign z = (state==S3 && !x);
     
          
endmodule
