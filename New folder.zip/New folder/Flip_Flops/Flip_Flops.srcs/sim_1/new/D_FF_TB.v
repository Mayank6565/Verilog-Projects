
module D_FF_TB(

    );
    reg clk,rst,d;
    wire q,qbar;
    D__FF dut(rst,clk,d,q,qbar);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    
    rst=1;
    d=0;
    #2;
    rst=0;
    #12;
    d=1;
    #7;
   $finish;
    end
endmodule
