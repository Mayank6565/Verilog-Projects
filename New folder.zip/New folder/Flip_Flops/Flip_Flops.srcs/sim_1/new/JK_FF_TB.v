

module JK_FF_TB(

    );
     reg rst,J,K,clk;
    wire q,qbar;
    integer m;
    JK_FF dut(J,K,rst,clk,q,qbar);
    
    initial 
    begin
    clk=0;
    forever #5 clk = ~clk;//Time period of clock=5ns
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b clk=%b J=%b K=%b q=%b qbar=%b",
         $time, rst, clk, J,K, q, qbar);
    J=0;
    K=0;
    rst=1;
    
    #2;
    
    rst=0;
    
    for(m=0;m<4;m=m+1)
   begin
   {J,K}=m;
   #10;
    end
    
    // Asynchronous Reset Test
    rst=1;
    #2;
    rst=0;
    #2;
    $finish;
    end
endmodule
