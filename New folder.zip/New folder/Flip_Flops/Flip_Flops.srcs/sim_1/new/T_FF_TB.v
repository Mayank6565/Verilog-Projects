
module T_FF_TB(

    );
    reg t,clk,rst;
    wire q,qbar;
    T_FF dut(rst,clk,t,q,qbar);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time =%0t, rst=%b, t=%b, q=%b ,qbar =%b",$time,rst,t,q,qbar);
    rst=1;
    t=0;
    #2;
    rst=0;
    #9;
    
  t=1;
#10;
$finish;
    end
endmodule
