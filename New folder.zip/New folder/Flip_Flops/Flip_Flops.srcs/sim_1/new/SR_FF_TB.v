
module SR_FF_TB(

    );
    reg rst,S,R,clk;
    wire q,qbar;
    integer m;
    SR_FF dut(S,R,rst,clk,q,qbar);
    
    initial 
    begin
    clk=0;
    forever #5 clk = ~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b clk=%b S=%b R=%b q=%b qbar=%b",
         $time, rst, clk, S, R, q, qbar);
    S=0;
    R=0;
    rst=1;
    
    #2;
    
    rst=0;
    
    for(m=0;m<4;m=m+1)
   begin
   {S,R}=m;
   #10;
    end
    
    // Asynchronous Reset Test
    rst=1;
    #2;
    rst=0;
    #2;
    $finish;
    end
    
endmodule
