

module JK_FF(
input J,K,rst,clk,output reg q, output qbar
    );
    always@(posedge clk or posedge rst)
    begin
    if(rst)
        q<=1'b0;
     else 
        begin
        case({J,K})
        2'b00: ;//Hold the prevoius value
        2'b01: q<=1'b0;//Reset
        2'b10: q<=1'b1;//Set
        2'b11: q<= ~q;//Toggle
        endcase 
        end
    end
    assign qbar =~q;
endmodule
