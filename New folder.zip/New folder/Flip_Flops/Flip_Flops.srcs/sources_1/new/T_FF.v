

module T_FF(
input rst,clk,t,output reg q,output qbar
    );
    always@(posedge clk or posedge rst)
    begin
    if(rst)
           q<=1'b0;
     else
            begin
            case(t)
            1'b0: ;//Hold
            1'b1: q<=~q;
            endcase
            end      
    end
    assign qbar=~q;
endmodule
