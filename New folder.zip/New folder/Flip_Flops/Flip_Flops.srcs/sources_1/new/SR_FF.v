

module SR_FF(
input S,R,rst,clk,output reg q, output qbar
    );
    always@(posedge clk or posedge rst)
    begin
    if(rst)
        q<=1'b0;
     else 
        begin
        case({S,R})
        2'b00: ;//Hold the prevoius value
        2'b01: q<=1'b0;
        2'b10: q<=1'b1;
        2'b11: q<=1'bx;
        endcase 
        end
    end
    assign qbar =~q;
endmodule
