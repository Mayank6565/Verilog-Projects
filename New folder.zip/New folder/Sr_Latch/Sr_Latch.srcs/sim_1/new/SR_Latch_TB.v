

module SR_Latch_TB(

    );
    reg enb,rst,r,s;
    wire q,qbar;
    integer m;
    SR_Latch dut(enb,rst,r,s,q,qbar);
    
    initial
    begin
    $monitor("The value of s=%b,r=%b,enb=%b,rst=%b,q=%b,qbar=%b",s,r,enb,rst,q,qbar);
    rst=1;
    enb=0;
    s=0; 
    r=0; 
    
    #10;
    
    rst=0;//Release reset
    
    
    //Begin Testing--
    for(m=0;m<8;m=m+1)
    begin
        {enb,s,r} = m;
        #10;
    end
    $finish;
    end
endmodule
