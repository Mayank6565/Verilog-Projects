

module SR_Latch(
input enb,rst,r,s,output reg q,qbar
    );
    
      always@(*)
      begin
        if(rst)
            begin
            q=1'b0;
            qbar = 1'b1;
            end  
        else if(enb)
            begin
           case({s,r})
           2'b00: ;//Hold
           2'b01:
                 begin
                 q=1'b0;
                 qbar=1'b1;
                 end
           2'b10: 
                  begin
                  q=1'b1;
                 qbar=1'b0;
                  end 
               
           2'b11:  begin
                  q=1'bx;
                 qbar=1'bx;
                  end 
                         
           endcase
          end 
       
                  // enb = 0 -> Hold
            end          
endmodule
