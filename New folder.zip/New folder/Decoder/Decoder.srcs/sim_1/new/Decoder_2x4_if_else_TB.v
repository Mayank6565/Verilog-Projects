
module Decoder_2x4_if_else_TB;
reg [1:0]ain;
wire [3:0]y;
integer m;
Decoder_2x4_if_else dut(ain,y);
initial 
begin
$monitor("The value of din=%b,out=%b",ain,y);
for (m=0;m<4;m=m+1)
begin
ain=m;
#1;
end
$finish;
end
endmodule
