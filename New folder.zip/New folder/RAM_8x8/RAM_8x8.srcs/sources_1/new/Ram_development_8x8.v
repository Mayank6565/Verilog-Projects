

module Ram_development_8x8(
input rst,clk,wr,input [2:0]wa,ra,input [7:0] data_in,output reg [7:0] data_out
    );//wr = write or read operation
    // wa = writing address
    // ra = reading address
    reg [7:0] mem[7:0];
   integer x;
    
    always@(posedge clk or posedge rst)
    begin
    
    if(rst) 
        begin
        
        for(x=0;x<8;x=x+1)
       mem[x]<=8'd0;
        data_out<=8'd0;
        
        end
     
     else if(wr)
            mem[wa]<=data_in;
     else
        data_out<= mem[ra];       
        
               
    end
endmodule
