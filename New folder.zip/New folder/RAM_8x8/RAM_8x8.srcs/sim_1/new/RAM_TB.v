
module RAM_TB(

    );
    reg rst,clk,wr;
    reg [2:0]wa,ra;
    reg [7:0] data_in;
    wire [7:0] data_out;
    Ram_development_8x8 dut(rst,clk,wr,wa,ra,data_in,data_out);
     integer i;
    task reset_logic;
    begin
    rst=1;
    @(posedge clk);
    #1;
    rst=0;
    end
    endtask
   
    initial
    begin
    clk=0;
   forever  #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b wa=%b wr=%b ra=%b data_in=%b data_out =%b,mem0=%b,mem1=%b,mem2=%b,mem3=%b,mem4=%b,mem5=%b,mem6=%b,mem7=%b",$time, rst,wa,wr,ra,data_in,data_out,dut.mem[0],dut.mem[1],dut.mem[2],dut.mem[3],dut.mem[4],dut.mem[5],dut.mem[6],dut.mem[7]);
    
    reset_logic();
    
  for(i=0;i<8;i=i+1)
  //Writng
  begin
  wr=1;
  wa=i;
  data_in=i;
  @(posedge clk);
  #1;
  end
   
 data_in=8'd0;
  
  for(i=0;i<8;i=i+1)
  begin
  //Reading
  wr=0;
  ra =i;
   @(posedge clk);
  #1;
  end
 
  
  
   //Resetting the memory
   @(posedge clk);
   #1;
  reset_logic();
  #1;
  $finish;
    
    
    end
    
endmodule
