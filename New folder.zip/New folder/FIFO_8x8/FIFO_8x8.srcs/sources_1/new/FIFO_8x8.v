

module FIFO_8x8(
input clk,rst,w,r,input [7:0] data_in,output reg [7:0] data_out,output full,empty
    );
    
    reg [7:0] mem[0:7];// Both are same --- reg [7:0] mem[7:0] is equal to reg [7:0] mem[0:7] for defining address and no link to endianess
    reg [2:0]wp;
    reg [2:0]rp;
    reg [3:0]count;//It shows the number of valid entries that are left in fifo
   //Count is of 4 bits because we have to count till 8
    integer i;
    
    always@(posedge clk or posedge rst)
    begin
    if(rst)
        begin
        for(i=0;i<8;i=i+1)
        mem[i]<=8'd0;
        wp<=3'd0;
        rp<=3'd0;
        data_out<=8'd0;
        end
    else    
        begin
        //Writing
        if(w&&!full) 
            begin
            mem[wp]<=data_in;
            wp<=wp+1'd1;
            end
            
        if(r&&!empty)//Both operations are permitted in the same cycle
              begin
              //Reading
            data_out<=mem[rp];
            rp<=rp+1'd1;
            end  
                    
    end
    end
    
    always@(posedge clk or posedge rst)
    begin
    if(rst)
        count<=4'd0;
    else    
    begin
    case({w && !full, r && !empty})//Important!!!
    2'b00: ;
    2'b01: count<=count-1'b1;
    2'b10: count<=count+1'b1;
    2'b11: ;
    default: count<=count;
    endcase
    end
    end
    
    assign full = (count==4'd8);
    assign empty = (count==4'd0);
    
endmodule
