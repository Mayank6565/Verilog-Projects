

module FIFO_8x8_TB(

    );
    reg clk,rst,w,r;
    reg [7:0]data_in;
    wire full,empty;
    wire [7:0] data_out;
    integer i;
    FIFO_8x8 dut(clk,rst,w,r,data_in,data_out,full,empty);
    
    task reset;
    begin
    rst=1;
    w=0;
    r=0;
    @(posedge clk);
    #1;
    rst=0;
    end
    endtask
    
    
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor(" rst=%b, w=%b,r=%b,data_in=%b,data_out=%b,count=%b,full=%b,empty=%b, wp=%b,rp=%b",rst,w,r,data_in,data_out,dut.count,dut.full,dut.empty,dut.wp,dut.rp);
    reset();
   
    begin
    //Writing
      for(i=0;i<8;i=i+1)
    begin
    w=1;
    r=0;
    data_in=i;
    @(posedge clk);
    #1;
    end
    
    data_in=0;
    
    //Reading
    for(i=0;i<8;i=i+1)
    begin
    r=1;
    w=0;
    @(posedge clk);
    #1;
    end
   
   //Checking for both w==1 and r==1
   for(i=0;i<4;i=i+1)
    begin
    w=1;
    r=0;
    data_in=i;
    @(posedge clk);
    #1;
    end

    

    for(i=0;i<4;i=i+1)
    begin
    w=1;
    r=1;
    data_in=i;
    @(posedge clk);
    #1;
    end

// r=0,w=0 case
//Nothing works in this case    
    r=0;
    w=0;
    @(posedge clk);
    #1;
   
   //Overflow testing
    for(i=0;i<11;i=i+1)
    begin
    w=1;
    r=0;
    data_in=i;
    @(posedge clk);
    #1;
    end
    reset();
    
    //Underflow Testing
    reset();
    for(i=0;i<2;i=i+1)
    begin
    r=1;
    w=0;
    @(posedge clk);
    #1;
    end
    
   reset();
   
    end
        $finish;  
    end
   
endmodule
