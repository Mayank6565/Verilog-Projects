

module Ripple_Carry_Adder_TB(

    );
    reg [3:0] a_tb,b_tb;
    reg c_tb;
    wire [3:0] sum_tb;
    wire carry_tb;
    Ripple_Carry_Adder dut(a_tb,b_tb,c_tb,sum_tb,carry_tb);
    initial
    begin
    $monitor("a_tb=%b,b_tb=%b,c_tb=%b,sum_tb=%b,carry_tb=%b",a_tb,b_tb,c_tb,sum_tb,carry_tb);
     a_tb=4'b0000; b_tb=4'b0000; c_tb=0; #1;
    a_tb=4'b0001; b_tb=4'b0010; c_tb=0; #1;
    a_tb=4'b0110; b_tb=4'b1110; c_tb=1; #1;
    a_tb=4'b1111; b_tb=4'b1111; c_tb=1; #1;

    $finish;
    end
endmodule
