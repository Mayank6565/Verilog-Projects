

module Full_Adder(
input a,b,c_in, output reg sum,carry
    );
    always@(*)
    begin
    sum = (a^b^c_in);
    carry = (a&b) | (c_in&(a^b));
    end
endmodule
