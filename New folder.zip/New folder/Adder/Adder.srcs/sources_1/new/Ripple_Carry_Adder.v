
module Ripple_Carry_Adder(input [3:0] a_rca,b_rca,input c_in, output cout_rca,output [3:0]sum_rca);
wire w1,w2,w3;
Full_Adder FA1(.a(a_rca[0]),.b(b_rca[0]),.cin(c_in),.sum(sum_rca[0]),.carry(w1));
Full_Adder FA2(.a(a_rca[1]),.b(b_rca[1]),.cin(w1),.sum(sum_rca[1]),.carry(w2));
Full_Adder FA3(.a(a_rca[2]),.b(b_rca[2]),.cin(w2),.sum(sum_rca[2]),.carry(w3));
Full_Adder FA4(.a(a_rca[3]),.b(b_rca[3]),.cin(w3),.sum(sum_rca[3]),.carry(cout_rca));


endmodule
