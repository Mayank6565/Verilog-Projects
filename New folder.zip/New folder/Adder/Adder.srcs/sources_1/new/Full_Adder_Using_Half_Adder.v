`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06.06.2026 16:19:31
// Design Name: 
// Module Name: Full_Adder_Using_Half_Adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Full_Adder_Using_Half_Adder(input A,B,Cin,output Sum,Carry );
wire w1,w2,w3;
Half_Adder ha1(.a(A),.b(B),.sum(w1),.carry(w2));
Half_Adder ha2(.a(w1),.b(Cin),.sum(Sum),.carry(w3));
or (Carry,w2,w3);

endmodule
