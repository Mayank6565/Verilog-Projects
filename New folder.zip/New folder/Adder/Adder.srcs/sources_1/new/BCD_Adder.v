
module BCD_Adder(input [3:0] a_bcd,b_bcd,input cin_bcd,output cout_bcd,output [3:0]sum_bcd);
wire [3:0]temp_sum;
wire [3:0]correction;
wire k;
wire dummy_cout;
wire temp_cout;
Ripple_Carry_Adder rca1(.a_rca(a_bcd),.b_rca(b_bcd),.c_in(cin_bcd),.cout_rca(temp_cout),.sum_rca(temp_sum));
assign k = temp_cout|(temp_sum[2]&temp_sum[3]) | (temp_sum[1]&temp_sum[3]);
assign correction = {4{k}}& 4'b0110;
Ripple_Carry_Adder rca2(.a_rca(temp_sum),.b_rca(correction),.c_in(1'b0),.cout_rca(dummy_cout),.sum_rca(sum_bcd));
assign cout_bcd = k;
endmodule
