
module Priority_Encoder_TB(

    );
    reg [3:0] ain;
    wire [1:0] y;
    integer m;
    Priority_Encoder dut(ain,y);
    initial 
    begin
    for(m=0;m<16;m=m+1)
    begin
    ain = m;
    #1;
    end
    $finish;
    end
endmodule
