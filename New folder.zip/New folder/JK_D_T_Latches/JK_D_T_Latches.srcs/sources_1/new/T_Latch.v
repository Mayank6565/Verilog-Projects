

module T_Latch(
input enb,rst,t,output reg q, output qbar
    );
    always@(*)
    begin
    if(rst)
           q=0;
     else if(enb)
            case(t)
            0: ;//Hold previous value
            1: q = ~q;
            endcase      
    end
    assign qbar = ~q;
endmodule
