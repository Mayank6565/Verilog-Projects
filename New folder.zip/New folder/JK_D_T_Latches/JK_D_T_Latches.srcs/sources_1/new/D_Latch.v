

module D_Latch(
input enb,rst,d,output reg q, output qbar    );
always@(*)
    begin 
        if(rst)
             begin
            q = 1'b0;
            end
            
         else if(enb)
            q=d;
                
    end
   assign  qbar = ~q;
endmodule
