

module JK_Latch(
input j,k,enb,rst,output reg q,qbar
    );
    always@(*)
    begin
    if(rst)
    begin
    q=1'b0; 
    qbar=1'b1; 
    end
    else if(enb)
        case({j,k})
            2'b00:;
            2'b01: begin
                    q=1'b0; 
                    qbar=1'b1; 
                   end
            2'b10:    begin
                    q = 1'b1; 
                    qbar=1'b0; 
                   end  
                   
             2'b11:    begin
                    q = ~q; 
                    qbar=~qbar; 
                   end  
              
              endcase  
              
                     
    end  
endmodule
