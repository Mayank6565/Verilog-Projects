

module D_Latch_TB(

    );
    reg d,rst,enb;
    wire q,qbar;
    integer k;
    D_Latch dut(enb,rst,d,q,qbar);
    initial
    begin
    $monitor("time=%0t | rst=%b | enb=%b | d=%b | q=%b | qbar=%b",$time, rst,enb,d,q,qbar);
    enb=0;
    rst=1;
    d=0;
    #10;
    rst=0;
    #10;
    //Begin testing using for loop
    for(k=0;k<4;k=k+1)
    begin
    {enb,d} = k;
    #10;
    end
    $finish;
    end
endmodule
