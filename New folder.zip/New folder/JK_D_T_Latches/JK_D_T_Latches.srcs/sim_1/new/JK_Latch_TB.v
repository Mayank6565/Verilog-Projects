
module JK_Latch_TB(

    );
    reg enb,j,k,rst;
    wire q,qbar;
    integer x ;
    JK_Latch dut(j,k,enb,rst,q,qbar);
    
    initial
    begin
    $monitor("x=%0d ,j=%b, k=%b, enb=%b, rst=%b, q=%b, qbar=%b",
         x,j,k,enb,rst,q,qbar);
    j=0;
    k=0;
    enb=0;
    rst=1;
    
    //Release Reset
    #10;
    rst=0;
    //Start Testing
    for(x=0;x<8;x=x+1)
    begin
    {enb,j,k} = x;
    #10;
    end
    
    $finish;
    end
endmodule
