
module T_latch_TB(

    );
    reg enb,rst,t;
    wire q,qbar;
    T_Latch dut(enb,rst,t,q,qbar);
    integer k;
    initial
    begin
    $monitor("time=%0t | rst=%b | enb=%b | t=%b | q=%b | qbar=%b",$time, rst,enb,t,q,qbar);
    enb=0;
    rst=1;
    t=0;
    #5;
    rst=0;
    #5;
    //Begin testing using for loop
    for(k=0;k<4;k=k+1)
    begin
    {enb,t} =k;
    #5;
    end
    $finish;
    end
endmodule
