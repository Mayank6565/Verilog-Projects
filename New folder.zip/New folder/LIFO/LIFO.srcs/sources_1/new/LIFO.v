

module LIFO_8x8(
input rst,clk,push,pop,input [7:0] data_in,output full,empty,output reg [7:0] data_out
    );
    reg [3:0] sp;
    reg [7:0] mem[0:7];
    integer i;
    always@(posedge clk or posedge rst)
    begin
    if(rst)
        begin
        for(i=0;i<8;i=i+1)
        mem[i] <= 8'd0;
        sp<=3'd0;
        data_out<=8'd0;
        end
       
    else if(push&&pop&&!empty)
            begin
             data_out<=mem[sp-1];
            mem[sp-1]<=data_in;
            end
                
     else if(push&&!full)
            begin
            mem[sp]<=data_in;
            sp<=sp+1'd1;
            end   
     else if(pop && !empty)
            begin
            data_out<=mem[sp-1];
            sp<=sp-1'd1;
            end
           
    end
    assign full= (sp==4'd8);
    assign empty = (sp==4'd0);
endmodule
