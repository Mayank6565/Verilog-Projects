

module LIFO_8x8_TB(

    );
    reg rst,clk,push,pop;
    reg [7:0] data_in;
    wire full,empty;
    wire [7:0] data_out;
    integer i;
    
    task reset;
    begin
    rst=1;
    @(posedge clk);
    #1;
    rst=0;
    push=0;
    pop=0;
    end
    
    endtask
    
    LIFO_8x8 dut(rst,clk,push,pop,data_in,full,empty,data_out);
    
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time =%0t, rst=%b, push=%b, pop=%b, data_in=%b,data_out=%b,sp=%b,full=%b,empty =%b",$time, rst,push,pop,data_in,data_out,dut.sp,dut.full,dut.empty);
    reset();
    //Filling the stack
    for(i=0;i<8;i=i+1)
        begin
        push=1;
        pop=0;
        data_in=i;
        @(posedge clk);
        #1;
        end
        
        data_in=8'd0;
        
      for(i=0;i<8;i=i+1)
        begin
        push=0;
        pop=1;
        @(posedge clk);
        #1;
        end 
        
        reset();
        //testing for both push=1 and pop=1
        
        //1. Inputting some data first 
       for(i=0;i<5;i=i+1)
        begin
        push=1;
        pop=0;
        data_in=i;
        @(posedge clk);
        #1;
        end  
        
         data_in=8'd0;
         
        //2.Performing the main action
         for(i=5;i<8;i=i+1)
        begin
        push=1;
        pop=1;
         data_in=i;
        @(posedge clk);
        #1;
        end 
         
       
        push=0;
        pop=0;
         @(posedge clk);
        #1;
        
        //For both push=pop=1
        for(i=0;i<5;i=i+1)
        begin
        push=1;
        pop=0;
        data_in=i;
        @(posedge clk);
        #1;
        end  
        
        push=1;
        pop=1;
        @(posedge clk);
        #1;
        reset();
        
        //Overflow testing
        for(i=0;i<12;i=i+1)
        begin
        push=1;
        pop=0;
        data_in=i;
        @(posedge clk);
        #1;
        end
        
        #1;
        data_in=8'd0;
        
        //Underflow Testing--
        reset();
         for(i=0;i<3;i=i+1)
        begin
        push=0;
        pop=1;
        @(posedge clk);
        #1;
        end 
        
        @(posedge clk);
        #1;
        $finish;
    end
    
endmodule
