

module Two_Bit_Comparator(input A0,A1,B0,B1, output gt,lt,eq);

wire w1,w2,w3,w4,w5,w6,w7,w8,w9,w10,w11,w12;

not n1(w10,A1);
not n2(w11,A0);
not n3(w9,B1);
not n4(w8,B0);

and a1(w1,A1,w9);
and a2(w3,A0,w8);
xnor x1(w2,A1,B1);
and a3(w4,w2,w3);
or o1(gt,w1,w4);

and a4(w5,w10,B1);
and a6(w6,B0,w11);
and a5(w12,w2,w6);
or o2(lt,w5,w12);

xnor x2(w7,A0,B0);
and a7(eq,w2,w7);
endmodule
