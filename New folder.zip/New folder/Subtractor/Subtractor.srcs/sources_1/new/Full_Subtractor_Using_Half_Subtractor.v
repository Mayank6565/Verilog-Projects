`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06.06.2026 17:15:50
// Design Name: 
// Module Name: Full_Subtractor_Using_Half_Subtractor
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Full_Subtractor_Using_Half_Subtractor(input A,B,Bin, output D,Bout);
wire w1,w2,w3;
Half_Subtractor hs_1(.a(A),.b(B),.difference(w1),.borrow(w2));
Half_Subtractor hs_2(.a(w1),.b(Bin),.difference(D),.borrow(w3));
or o1(Bout,w2,w3);
endmodule
