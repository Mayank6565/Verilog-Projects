module Full_Subtractor(input a,b,bin, output difference,borrow);
wire w1,w2,w3,w4,w5;
xor x1(w1,a,b);
xor x2(difference,bin,w1);
not n1(w2,w1);
and a1(w3,w2,bin);
not n2(w4,a);
and a2(w5,w4,b);
or o1(borrow,w3,w5);
endmodule