

module Full_Adder_TB();
reg a_tb,b_tb,cin_tb;
wire sum_tb,carry_tb;
Full_Adder dut(a_tb,b_tb,cin_tb,sum_tb,carry_tb);
initial
begin
$monitor("a=%b,b=%b,c_in=%b,sum=%b,carry=%b",a_tb,b_tb,cin_tb,sum_tb,carry_tb); 
a_tb=1'b0;
b_tb=1'b0;
cin_tb =1'b0;


#1;
a_tb=1'b0;
b_tb=1'b0;
cin_tb =1'b1;

#1;
a_tb=1'b0;
b_tb=1'b1;
cin_tb =1'b0;

#1;
a_tb=1'b0;
b_tb=1'b1;
cin_tb =1'b1;

#1;
a_tb=1'b1;
b_tb=1'b0;
cin_tb =1'b0;

#1;
a_tb=1'b1;
b_tb=1'b0;
cin_tb =1'b1;

#1;
a_tb=1'b1;
b_tb=1'b1;
cin_tb =1'b0;

#1;
a_tb=1'b1;
b_tb=1'b1;
cin_tb =1'b1;
#1;
$finish;
end
endmodule
