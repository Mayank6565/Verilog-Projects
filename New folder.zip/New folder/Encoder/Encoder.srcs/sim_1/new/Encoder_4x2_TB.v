

module Encoder_4x2_TB;
    reg [3:0]D;
    wire [1:0] Q;
    integer m;
    Enoder_4x2 dut(D,Q);
    initial
    begin
    $monitor("The value of D=%b,Q=%b",D,Q);
    for(m=0;m<16;m=m+1)
    begin
    D=m;
    #1;
    end
    $finish;
    end
endmodule
