

module Enoder_4x2(
input [3:0]D,output reg [1:0]Q
    );
    always@(*)
    begin
   if(D==4'b0001)
   Q=2'b00;
   else if(D==4'b0010)
   Q=2'b01;
   else if(D==4'b0100)
    Q=2'b10;
    else if(D==4'b1000)
    Q=2'b11;
    else
    Q=2'bxx;
    
    end
endmodule
