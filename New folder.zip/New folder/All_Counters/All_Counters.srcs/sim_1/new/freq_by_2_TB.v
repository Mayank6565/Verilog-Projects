

module freq_by_2_TB(

    );
    reg rst,clk;
    wire q;
    freq_by_2 dut(clk,rst,q);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    rst=1;
    #1;
    @(posedge clk);
    #1;
    rst=0;
    repeat(5)@(posedge clk);
    #1;
    rst=1;
    #1;
    @(posedge clk);
    $finish;
    end
endmodule
