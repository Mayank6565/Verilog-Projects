
module freq_by_2_4_8_16_TB(

    );
    reg clk,rst,enb;
    reg [1:0] m;
    wire q;
    freq_by_2_4_8_16 dut(clk,rst,enb,m,q);
     initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b m=%b count=%b q=%b",
         $time,rst,enb,m,dut.count,q);
    rst=1;
    enb=0;
    m=2'b00;
    #1;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(4) @(posedge clk);
    #1;
    m=2'b01;
    repeat(8) @(posedge clk);
    #1;
    m=2'b10;
    repeat(16) @(posedge clk);
    #1;
    enb=0;
    @(posedge clk);
    #1;
    enb=1;
    m=2'b11;
    repeat(32) @(posedge clk);
    #1;
    rst=1;
    #1;
    @(posedge clk);
    #1;
    $finish;
    end
endmodule
