module MOD_8_Counter(
input rst,clk,enb,output reg [2:0]count
    );
     always@(posedge clk)
    begin
    if(rst)
        count<=3'b000;
    else if(enb)
            count<=count + 3'b001;
             
    end
endmodule
