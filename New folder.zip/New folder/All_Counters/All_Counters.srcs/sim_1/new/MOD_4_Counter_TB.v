module MOD_4_Counter_TB(

    );
    reg clk,rst,enb;
    wire [1:0] count;
    MOD_4_Counter dut(clk,rst,enb,count);
    
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time =%0t,rst=%b,enb=%b,count=%b",$time,rst,enb,count);
    
    rst=1;
    enb=0;
    
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    
    repeat(2) @(posedge clk);
    #1;
    rst=1;
    
    @(posedge clk);
    #1;
    rst=0;
    repeat(3) @(posedge clk);
    #1;
    rst=1;
    
    
   $finish;
   
    end
    
endmodule


