
module Combined_3_5_7_9_MOD_TB(

    );
    reg rst,clk,enb;
    reg [1:0]m;
    reg direc;
    wire [3:0] count;
    MOD_3_5_7_9_Combined_UP_DOWN dut(clk,enb,rst,m,direc,count);
    
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
     $monitor("time=%0t rst=%b enb=%b m=%b count=%b direc=%b ",
         $time,rst,enb,m,count,direc);
         
    rst=1;
    enb=0;
    m=2'b00;
    direc=1;
    #1;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(3) @(posedge clk);
    #1;
    m=2'b01;
    #1;
    repeat(6) @(posedge clk);
    #1;
    m = 2'b10;
    #1;
    repeat(8) @(posedge clk);
    #1;
    rst=1;
    #1;
    @(posedge clk);
    #1;
    rst=0;
    direc=0;
    #1;
    @(posedge clk);
    #1;
    m = 2'b11;
    #1;
    repeat(10) @(posedge clk);
    #1;
    rst=1;
    #1;
    @(posedge clk);
    #1;
    $finish;
  
  end
endmodule
