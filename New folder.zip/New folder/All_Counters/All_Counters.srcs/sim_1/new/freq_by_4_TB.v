
module freq_by_4_TB(

    );
    reg rst,clk,enb;
    wire q;
    freq_by_4 dut(rst,enb,clk,q);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b q=%b",
         $time,rst,enb,q);
    rst=1;
    enb=0;
    #1;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(8)@(posedge clk);
    #1;
    rst=1;
    #1;
    @(posedge clk);
    enb=0;
    rst=0;
    @(posedge clk); 
    $finish;
    end
endmodule
