
module freq_by_3_TB(

    );
    reg clk,enb,rst;
    wire f;
    
    freq_by_3 dut(clk,enb,rst,f);
    
     initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b f=%b q=%b",
         $time,rst,enb,f,dut.q);
         
    rst=1;
    enb=0;
    #1;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(12)@(posedge clk);
    #1;
    rst=1;
    #1;
    @(posedge clk);
    
    rst=0;
    #1;
    @(posedge clk); 
    #1;
    $finish;
    end
endmodule
