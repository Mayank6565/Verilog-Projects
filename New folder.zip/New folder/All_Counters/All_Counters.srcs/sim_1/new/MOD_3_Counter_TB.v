
module MOD_3_Counter_TB(

    );
    reg rst,enb,clk;
    wire [1:0] q;
    MOD_3_Counter dut(clk,enb,rst,q);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t,rst=%b,enb=%b,q=%b",$time,rst,enb,q);
    rst=1;
    enb=0;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(5) @(posedge clk);
    #1;
    rst=1;
    @(posedge clk);
    #1;
    $finish;
    end
endmodule
