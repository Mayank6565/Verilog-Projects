module MOD_5_Counter_TB(

    );
    reg rst,enb,clk;
    wire [2:0] count;
    MOD_5_Counter dut(rst,clk,enb,count);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t,rst=%b,enb=%b,count=%b",$time,rst,enb,count);
    rst=1;
    enb=0;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(4) @(posedge clk);
    #1;
    rst=1;
    @(posedge clk);
    #1;
    $finish;
    end
endmodule
