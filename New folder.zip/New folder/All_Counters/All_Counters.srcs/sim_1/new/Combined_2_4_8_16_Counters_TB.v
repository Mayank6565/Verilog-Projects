
module Combined_2_4_8_16_Counters_TB(

    );
    reg rst,clk,enb,direc;
    reg [1:0]m;
    wire [3:0] count;
    Combined_2_4_8_16_Counters dut(rst,clk,enb,m,direc,count);
    
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b m=%b count=%b",
          $time, rst, enb, m, count);
    
    rst=1;
    enb=0;
    direc=1;
    #1;
    m=2'b00;
    @(posedge clk);
    #1;
    rst=0;
    enb=1;
    repeat(2) @(posedge clk);
    #1;
    rst=1;
    @(posedge clk);
    #1;
    rst=0;
    #1;
    m=2'b01;
    
    repeat(3) @(posedge clk);
    #1;
    rst=1;
    @(posedge clk);
    #1;
    rst=0;
    #1;
    m=2'b10;
    repeat(7) @(posedge clk);
    #1;
    rst=1;
    @(posedge clk);
    #1;
    rst=0;
    #1;
    m=2'b11;
    direc=0;
    repeat(15) @(posedge clk);
    #1;
    rst=1;
    @(posedge clk);
    #1;
    $finish;
    
    end
endmodule
