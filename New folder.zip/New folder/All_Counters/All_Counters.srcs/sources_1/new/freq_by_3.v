module freq_by_3(
input clk,enb,rst,output f
    );
    reg [1:0] q;
    always@(posedge clk)
    begin
    if(rst)
        q<=2'b00;
        
    else if(enb)
            begin
            if(q==2'b10)
                q<=2'b00;
            else 
            q<=q+1'b1;    
            end    
    end
    assign f=q[1];
endmodule
