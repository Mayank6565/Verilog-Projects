
module MOD_5_Counter(
input rst,clk,enb,output reg [2:0]count
    );
    always@(posedge clk)
    begin
    if(rst)
           count<=3'd0;
           
    else if(enb)
            if(count==3'd4)
               count<=0;
            else   
                count<=count+1'b1;       
    end
endmodule



