
module MOD_4_Counter(
input clk,rst,enb, output reg [1:0]count
    );
    
    always@(posedge clk)
    begin
    if(rst)
        count<=2'b00;
    else if(enb)
            count<=count + 2'b01;
             
    end
    
endmodule
