
module MOD_3_5_7_9_Combined_UP_DOWN(
input clk,enb,rst,input [1:0]m,
input direc,//If direc==1:-Up counter or if direc==0: Down Counter 
output reg [3:0]count
 );
    reg [3:0] max_count;
    
    always @(*) begin
      
    case (m)
        2'b00: max_count = 4'd2;
  
        2'b01: max_count = 4'd4;
         
        2'b10:  max_count = 4'd6;
       
        2'b11: max_count = 4'd8;
        
        default: max_count = 4'd8;
    endcase
end

always@(posedge clk)
begin
if(rst)
    count<=4'd0;
    
    
 else if(enb&&direc)
          begin
          if(count>max_count)
    count<=0;

else if(count==max_count)
    count<=0;

else
    count<=count+1; 
          end
          
          
          
  else if(enb && !direc)
        begin
        if(count>max_count)
            count<=max_count;
        else if(count==4'd0)
            count<=max_count;
        else    
            count<=count-1'd1;       
        end
                   
end

endmodule
