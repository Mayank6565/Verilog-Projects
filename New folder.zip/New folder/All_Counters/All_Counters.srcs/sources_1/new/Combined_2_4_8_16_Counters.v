module Combined_2_4_8_16_Counters(
input rst, clk, enb,
input [1:0] m,
input direc,
output reg [3:0] count
);

reg [3:0] max_count, min_count;

// Determine maximum and minimum counts
always @(*) begin
    case (m)
        2'b00: begin
            max_count = 4'd1;
            min_count = 4'd0;
        end

        2'b01: begin
            max_count = 4'd3;
            min_count = 4'd0;
        end

        2'b10: begin
            max_count = 4'd7;
            min_count = 4'd0;
        end

        2'b11: begin
            max_count = 4'd15;
            min_count = 4'd0;
        end

        default: begin
            max_count = 4'd15;
            min_count = 4'd0;
        end
    endcase
end


always @(posedge clk)
begin
    if (rst)
        count <= 4'd0;

    else if (enb)
    begin

        // Robustness against changing m during counting
        if (count > max_count)
            count <= 4'd0;

        else if (direc)     // Up Counter
        begin
            if (count == max_count)
                count <= 4'd0;
            else
                count <= count + 1'b1;
        end

        else                // Down Counter
        begin
            if (count == min_count)
                count <= max_count;
            else
                count <= count - 1'b1;
        end

    end
end

endmodule