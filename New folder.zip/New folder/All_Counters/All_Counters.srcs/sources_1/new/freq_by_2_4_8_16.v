
module freq_by_2_4_8_16(
input clk,rst,enb,input [1:0]m,output reg q
    );
    reg [3:0] count;
    always@(posedge clk)
    begin
    if(rst)
        count<=4'b0000;
    else if(enb)
         count<=count+1'b1;       
            
    end
  
always@(*)
begin
    case (m)
    2'b00: q =count[0];
    2'b01: q=count[1];
    2'b10: q=count[2];
    2'b11: q=count[3];
    default: q = 1'b0;
    endcase
end

    
endmodule
