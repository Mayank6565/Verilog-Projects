
module freq_by_4(
input rst,enb,clk,output q
    );
    reg [1:0]count;
    always@(posedge clk)
    begin
    if(rst)
        count<=2'b00;
     else if(enb)
        count<=count+1'b1;   
    end
    assign q=count[1];
endmodule
