

module UART_TX_TB(

    );
    reg clk,rst,tx_start;
    reg [7:0]data_in;
    wire tx,busy,done;
    
    UART_TX dut(rst,clk,tx_start,data_in,tx,busy,done);
    
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    task reset;
    begin
    rst=1;
    @(posedge clk);
    rst=0;
    @(posedge clk);
    #1;
    end
    endtask
    
    
    initial
    begin
    $monitor("time=%0t state=%b baud_tick=%b busy=%b done=%b",
          $time,dut.state,dut.baud_tick,busy,done);
     tx_start=1'b0;
     data_in=8'd0;
     reset();
     tx_start = 1;
data_in  = 8'b10100101;

@(posedge clk);
tx_start = 0;
      #600000;
      $finish;
     
    end
endmodule
