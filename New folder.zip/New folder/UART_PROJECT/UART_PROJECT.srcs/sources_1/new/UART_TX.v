module UART_TX(input rst,clk,tx_start,input[7:0]data_in,output reg tx,busy,done);
parameter idle = 2'b00;
parameter start = 2'b01;
parameter data = 2'b10;
parameter stop  = 2'b11;

reg baud_tick;
reg [12:0]baud_count;
reg [7:0] shift_data;
reg [1:0]state,next_state;
reg [2:0]bit_count;

//Baud Generator
always@(posedge clk)
begin
if(rst)
    begin
    baud_count<=1'b0;
    baud_tick<=1'b0;
    end

else
    begin
    if(baud_count==13'd5207)
        begin
        baud_count<=13'b0;
        baud_tick<= 1'b1;
        end
     else
        begin
        baud_count<=baud_count+1'b1;
        baud_tick<=1'b0;
        end 
     end     
  end  
  
  //States 
  always@(posedge clk)
  begin
  if(rst)
    state <= idle;
  else
      state<=next_state;  
  end
      
  //Next State Condition
  always@(*)
  begin
  next_state=state;
  case(state)
  
  idle:
  begin
  if(tx_start)
    next_state = start;  
  end
  
  start: 
  begin
  if(baud_tick)
    next_state=data;
  end
  
  
  data:
  begin
 
  if(baud_tick)
    begin
    if(bit_count==7)
    next_state =stop;
    end
  end  
 
  
  
  stop:
  begin
  if(baud_tick)
    next_state = idle;
  end
  
  
  endcase   
  end
  
  //Shift_register Logic
 always@(posedge clk)
  begin
  
  if(rst)
    begin
    shift_data<=8'd0;
    bit_count<=3'b0;
    end
  else
  begin  
  case(state)
  
  idle:
  begin
  if(tx_start)
  begin
  shift_data<=data_in;
  bit_count<=3'b0;
  end
  end
  
  data: 
  begin
  if(baud_tick)
  begin
  if(bit_count !=3'd7)
  begin
  shift_data<=shift_data>>1;
  bit_count<=bit_count+1'b1;
  end
  end
  end
  endcase
  end
  end
  
  //Output logic
  always@(*)
  begin
  
  tx=1'b1;
  busy=1'b0;
  done=1'b0;
  case(state)
  
  
  idle: 
  begin
  tx=1'b1;
  busy=1'b0;
  end
  
  start:
  begin
  tx=1'b0;
  busy=1'b1;
  end
  
  data:
  begin
  tx=shift_data[0];
  busy=1'b1;
  end
  
  stop:
  begin
  tx=1'b1;
  busy=1'b1;
  if(baud_tick==1)
    done=1'b1;
  end
  
  endcase
  
  end
  
endmodule
