
module Universal_Shift_Operation(
input clk,rst,s_in,input[3:0]p_in,load,input [1:0]m, output s_out,output [3:0]p_out
    );
    reg [3:0]q;
    always@(posedge clk or posedge rst)
    begin
    
    if(rst)
    q<=4'b0000;
    
    else 
    
    begin
    case(m)
    2'b00: q<= (q>>1)|(s_in<<3);
           
    2'b01: q<= (q>>1)|(s_in<<3);
           
    2'b10: begin
           if(load)
                q<=p_in;
           else   
                q <= q>>1;
           end  
           
    2'b11: q<= p_in;
     default : q<=q;               
    endcase       
    end
    end
    assign s_out = q[0];
    assign p_out =q;
 
endmodule
