
module PISO(
input rst,enb,clk,load,input[3:0]p_in,output s_out
    );
    reg [3:0] q;
    always@(posedge clk or posedge rst)
    begin
    if(rst)
         q<=4'b0000;
         
     else if(enb)
            begin
            if(load)
                q<=p_in;
                
            else
                q<= (q>>1);    
            end     
    end
    assign s_out = q[0];
endmodule
