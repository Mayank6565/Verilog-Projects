

module SIPO(
input rst,clk,enb,s_in,output [3:0]s_out
    );
    reg [3:0]q;
    always@(posedge clk or posedge rst)
    begin 
    if(rst)
        q<=4'b0000;
    
    else if(enb)
            q<= (q>>1) |  (s_in<<3);        
    end
    assign s_out = q;
endmodule
