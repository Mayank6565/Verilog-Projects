
module SISO(
input s_in,clk,rst,enb,output s_out
    );
    reg[3:0] q;
    always@(posedge clk or posedge rst)
    begin 
    if(rst)
            q<=4'b0000;
     
     else if(enb)
//            q<=(q>>1)| (s_in<<3);
                q<= {s_in,q[3:1]};
                   
    end
    assign s_out = q[0];
endmodule
