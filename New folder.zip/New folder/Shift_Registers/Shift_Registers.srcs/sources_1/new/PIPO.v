
module PIPO(
input rst,enb,clk, input [3:0]p_in, output [3:0]p_out
    );
    reg [3:0]q;
    always@(posedge clk or posedge rst)
    begin
    if(rst)
           q<=4'b0000;
      
     else if(enb)
                 q<= p_in;  
    end
    assign p_out = q;
endmodule
