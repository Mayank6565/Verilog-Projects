
module PIPO_TB(

    );
    reg rst,clk,enb;
    reg [3:0] p_in;
    wire [3:0]p_out;
    PIPO dut(rst,enb,clk,p_in,p_out);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b p_in=%b p_out=%b",
         $time,rst,enb,p_in,p_out);
    enb=0;
    rst=1;
    p_in=4'b0000;
    #2;
    enb=1;
    rst=0;
    //4 Test cases--
    p_in = 4'b1101;#10;
    p_in = 4'b1001;#10;
    p_in = 4'b1111;#10;
    p_in = 4'b1100;#10;
    
    //Hold Condition--
    enb=0;
    p_in=4'b0111;#10;
    
    $finish;
    end
endmodule
