
module SISO_TB(

    );
    reg clk,s_in,enb,rst;
    wire s_out;
    SISO dut(s_in,clk,rst,enb,s_out);
    initial 
    begin  
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time =%0t,rst=%b, enb=%b, clk=%b,s_out=%b,q=%b",$time,rst,enb,clk,s_out,dut.q);
   rst=1;
   enb=0;
   s_in=0;
   
   #2;
   
   rst=0;
   enb=1;
   s_in=1;#10;
   s_in=0;#10;
   s_in=1;#10;
   s_in=1;#10;
   $finish;
   
    end
endmodule
