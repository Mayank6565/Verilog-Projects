
module SIPO_TB(

    );
    reg clk,rst,enb,s_in;
    wire [3:0]s_out;
    SIPO dut(rst,clk,enb,s_in,s_out);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b s_in=%b q=%b",
         $time,rst,enb,s_in,dut.q);
    enb=0;
    rst=1;
    s_in=0;
    
    #2;
    
    enb=1;
    rst=0;
    s_in = 1;#10;
    s_in = 0;#10;
    s_in = 1;#10;
    s_in = 1;#10;
    $finish;
    end
endmodule
