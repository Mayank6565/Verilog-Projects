
module USO_TB(

    );
    reg clk,rst,s_in,load;
    reg [3:0]p_in;
    reg [1:0]m;
    wire s_out;
    wire [3:0]p_out;
    
    Universal_Shift_Operation dut(clk,rst,s_in,p_in,load,m,s_out,p_out);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("Time=%0t rst=%b m=%b load=%b s_in=%b p_in=%b p_out=%b s_out=%b",
             $time, rst, m, load, s_in, p_in, p_out, s_out);
    rst=1;
    load=0;
    p_in=4'b0000;
    s_in=0;
    m=2'b00;
    
    #10;
    rst=0;
    
    //SISO  
    m=2'b00;
    s_in=1;#10;
    s_in=0;#10;
    s_in=1;#10;
    s_in=1;#10;
    
    //SIPO Cases
    
    m=2'b01;
    s_in=0;#10;
    s_in=1;#10;
    s_in=0;#10;
    s_in=1;#10;
    s_in=1;#10;
    
   //PISO cases
   m=2'b10;
   p_in = 4'b1011;#10;
   load=1;#10;
   load=0;
   repeat(4)
#10;
   
   //PIPO Cases
   m=2'b11;
      p_in = 4'b1101;#10;
    p_in = 4'b1001;#10;
    p_in = 4'b1111;#10;
    p_in = 4'b1100;#10;
    
    $finish;
    
    end
endmodule
