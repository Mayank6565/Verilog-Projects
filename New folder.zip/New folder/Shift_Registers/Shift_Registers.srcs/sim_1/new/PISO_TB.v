
module PISO_TB(

    );
    reg rst,clk,enb,load;
    reg[3:0]p_in;
    wire s_out;
    PISO dut(rst,enb,clk,load,p_in,s_out);
    initial
    begin
    clk=0;
    forever #5 clk=~clk;
    end
    
    initial
    begin
    $monitor("time=%0t rst=%b enb=%b load=%b p_in=%b q=%b s_out=%b",
         $time,rst,enb,load,p_in,dut.q,s_out);
    enb=0;
    rst=1;
    load=0;
    p_in=4'b1011;
    
    #2;
    rst=0;
    enb=1;
    
    //Loading
    load =1;
    #10;
    
    //Shifting
    load=0;
    #50;
    
    $finish;
    end
endmodule
