

module Half_Subtractor_TB(

    );
    reg a_tb,b_tb;
    wire difference_tb,borrow_tb;
    Half_Subtractor dut(a_tb,b_tb,difference_tb,borrow_tb);
    initial
    begin
    $monitor("a=%b, b=%b, difference=%b, borrow=%b",
              a_tb,b_tb,difference_tb,borrow_tb);
    a_tb=1'b0;
    b_tb=1'b0;
    #1;
    
    a_tb=1'b0;
    b_tb=1'b1;
    #1;
    
    a_tb=1'b1;
    b_tb=1'b0;
    #1;
    
    a_tb=1'b1;
    b_tb=1'b1;
    #1;
    $finish;
    end
endmodule
