
module Demux_1x2_TB(

    );
    reg s,in;
    wire [1:0] y;
    integer m;
    Demux_1x2_using_case dut(s,in,y);
    initial
    begin
    $monitor("The value of s=%b,in=%b,y=%b",s,in,y);
    for(m=0;m<4;m=m+1)
    begin
    {in,s}= m;
    #1;
    end
    $finish;
    end
endmodule
